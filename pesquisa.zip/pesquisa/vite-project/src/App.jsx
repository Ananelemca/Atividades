import Pesquisa from './components/Pesquisa'
import './App.css'

function App() {

  return (
    <>
      <Pesquisa/>
    </>
  )
}

export default App


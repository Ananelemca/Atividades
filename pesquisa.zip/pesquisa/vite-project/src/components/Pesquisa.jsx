
export default function Pesquisa(){
    return(
        <>
        <header>
        <input type="text" placeholder=" Pesquisar..."/>
        <button>Voltar</button>
        </header>
        <br />
        <div className="container">
            <img src="carregando.png"/>
            <h3>Cover - Justin Bieber</h3>
        </div>
        <div className="container">
            <img src="carregando.png"/>
            <h3>Juntos e Shallow Now (Cover)</h3>
        </div>
        <div className="container">
            <img src="carregando.png"/>
            <h3>The masks</h3>
        </div>
        <div className="container">
            <img src="carregando.png"/>
            <h3>Balé</h3>
        </div>
        
   </>
)
}
